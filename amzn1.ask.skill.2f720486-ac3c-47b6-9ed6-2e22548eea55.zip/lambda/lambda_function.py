# -*- coding: utf-8 -*-

# This sample demonstrates handling intents from an Alexa skill using the Alexa Skills Kit SDK for Python.
# Please visit https://alexa.design/cookbook for additional examples on implementing slots, dialog management,
# session persistence, api calls, and more.
# This sample is built using the handler classes approach in skill builder.
import logging
import ask_sdk_core.utils as ask_utils
import json
import boto3

from ask_sdk_core.skill_builder import SkillBuilder
from ask_sdk_core.dispatch_components import AbstractRequestHandler
from ask_sdk_core.dispatch_components import AbstractExceptionHandler
from ask_sdk_core.handler_input import HandlerInput

from ask_sdk_model import Response

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


class LaunchRequestHandler(AbstractRequestHandler):
    """Handler for Skill Launch."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool

        return ask_utils.is_request_type("LaunchRequest")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = "Welcome, you can say Hello or Help. Which would you like to try?"

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )


class HelloWorldIntentHandler(AbstractRequestHandler):
    """Handler for Hello World Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("HelloWorldIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = "Hello World!"

        return (
            handler_input.response_builder
                .speak(speak_output)
                # .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )


class HelpIntentHandler(AbstractRequestHandler):
    """Handler for Help Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("AMAZON.HelpIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = "You can say hello to me! How can I help?"

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )


class CancelOrStopIntentHandler(AbstractRequestHandler):
    """Single handler for Cancel and Stop Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return (ask_utils.is_intent_name("AMAZON.CancelIntent")(handler_input) or
                ask_utils.is_intent_name("AMAZON.StopIntent")(handler_input))

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        speak_output = "Goodbye!"

        return (
            handler_input.response_builder
                .speak(speak_output)
                .response
        )


class SessionEndedRequestHandler(AbstractRequestHandler):
    """Handler for Session End."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_request_type("SessionEndedRequest")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response

        # Any cleanup logic goes here.

        return handler_input.response_builder.response


class IntentReflectorHandler(AbstractRequestHandler):
    """The intent reflector is used for interaction model testing and debugging.
    It will simply repeat the intent the user said. You can create custom handlers
    for your intents by defining them above, then also adding them to the request
    handler chain below.
    """
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_request_type("IntentRequest")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        intent_name = ask_utils.get_intent_name(handler_input)
        speak_output = "You just triggered " + intent_name + "."

        return (
            handler_input.response_builder
                .speak(speak_output)
                # .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )


class CatchAllExceptionHandler(AbstractExceptionHandler):
    """Generic error handling to capture any syntax or routing errors. If you receive an error
    stating the request handler chain is not found, you have not implemented a handler for
    the intent being invoked or included it in the skill builder below.
    """
    def can_handle(self, handler_input, exception):
        # type: (HandlerInput, Exception) -> bool
        return True

    def handle(self, handler_input, exception):
        # type: (HandlerInput, Exception) -> Response
        logger.error(exception, exc_info=True)

        speak_output = "Sorry, I had trouble doing what you asked. Please try again."

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )

# The SkillBuilder object acts as the entry point for your skill, routing all request and response
# payloads to the handlers above. Make sure any new handlers or interceptors you've
# defined are included below. The order matters - they're processed top to bottom.


sb = SkillBuilder()

sb.add_request_handler(LaunchRequestHandler())
sb.add_request_handler(HelloWorldIntentHandler())
sb.add_request_handler(HelpIntentHandler())
sb.add_request_handler(CancelOrStopIntentHandler())
sb.add_request_handler(SessionEndedRequestHandler())
sb.add_request_handler(IntentReflectorHandler()) # make sure IntentReflectorHandler is last so it doesn't override your custom intent handlers

sb.add_exception_handler(CatchAllExceptionHandler())

lambda_handler = sb.lambda_handler()
def lambda_handler(event, context):
    # Get the service client
    kodi_client = boto3.client('kodi-media-player')

    # Get the intent name
    intent_name = event['currentIntent']['name']

    # Handle the Movie Search intent
    if intent_name == 'MovieSearch':
        movie_title = event['currentIntent']['slots']['MovieTitle']

        # Call the Kodi service to search for the movie
        response = kodi_client.search_movie(movie_title=movie_title)

        # Return the response
        return {
            'dialogAction': {
                'type': 'Close',
                'fulfillmentState': 'Fulfilled',
                'message': {
                    'contentType': 'PlainText',
                    'content': 'Here are the results for your search for {}'.format(movie_title)
                }
            },
            'slots': event['currentIntent']['slots'],
            'sessionAttributes': response
        }

    # Handle the TV Search intent
    elif intent_name == 'TVSearch':
        tv_title = event['currentIntent']['slots']['TVShowTitle']

        # Call the Kodi service to search for the TV show
        response = kodi_client.search_tv_show(tv_title=tv_title)

        # Return the response
        return {
            'dialogAction': {
                'type': 'Close',
                'fulfillmentState': 'Fulfilled',
                'message': {
                    'contentType': 'PlainText',
                    'content': 'Here are the results for your search for {}'.format(tv_title)
                }
            },
            'slots': event['currentIntent']['slots'],
            'sessionAttributes': response
        }

    # Handle the Movie Play intent
    elif intent_name == 'MoviePlay':
        movie_title = event['currentIntent']['slots']['MovieTitle']

        # Call the Kodi service to play the movie
        response = kodi_client.play_movie(movie_title=movie_title)

        # Return the response
        return {
            'dialogAction': {
                'type': 'Close',
                'fulfillmentState': 'Fulfilled',
                'message': {
                    'contentType': 'PlainText',
                    'content': 'Playing {} now'.format(movie_title)
                }
            },
            'slots': event['currentIntent']['slots'],
            'sessionAttributes': response
        }

    # Handle the TV Episode Play intent
    elif intent_name == 'TVEpisodePlay':
        tv_title = event['currentIntent']['slots']['TVShowTitle']
        episode_number = event['currentIntent']['slots']['EpisodeNumber']

        # Call the Kodi service to play the episode
        response = kodi_client.play_tv_episode(tv_title=tv_title, episode_number=episode_number)

        # Return the response
        return {
            'dialogAction': {
                'type': 'Close',
                'fulfillmentState': 'Fulfilled',
                'message': {
                    'contentType': 'PlainText',
                    'content': 'Playing episode {} of {} now'.format(episode_number, tv_title)
                }
            },
            'slots': event['currentIntent']['slots'],
            'sessionAttributes': response
        }

    # Handle the TV Episode Pause intent
    elif intent_name == 'TVEpisodePause':
        tv_title = event['currentIntent']['slots']['TVShowTitle']
        episode_number = event['currentIntent']['slots']['EpisodeNumber']

        # Call the Kodi service to pause the episode
        response = kodi_client.pause_tv_episode(tv_title=tv_title, episode_number=episode_number)

        # Return the response
        return {
            'dialogAction': {
                'type': 'Close',
                'fulfillmentState': 'Fulfilled',
                'message': {
                    'contentType': 'PlainText',
                    'content': 'Pausing episode {} of {} now'.format(episode_number, tv_title)
                }
            },
            'slots': event['currentIntent']['slots'],
            'sessionAttributes': response
        }

    # Handle the Specific TV Episode intent
    elif intent_name == 'SpecificTVEpisode':
        tv_title = event['currentIntent']['slots']['TVShowTitle']
        season_number = event['currentIntent']['slots']['SeasonNumber']
        episode_number = event['currentIntent']['slots']['EpisodeNumber']

        # Call the Kodi service to play the specific episode
        response = kodi_client.play_specific_tv_episode(tv_title=tv_title, season_number=season_number, episode_number=episode_number)

        # Return the response
        return {
            'dialogAction': {
                'type': 'Close',
                'fulfillmentState': 'Fulfilled',
                'message': {
                    'contentType': 'PlainText',
                    'content': 'Playing episode {} of season {} of {} now'.format(episode_number, season_number, tv_title)
                }
            },
            'slots': event['currentIntent']['slots'],
            'sessionAttributes': response
        } 